package javafx_aprendendo.Models;

import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class Funcionario
{
    private int id_Funcionario;
    private String Nome;
    private int Telefone;
    private float Salario;
    private String Cargo;
    private String Sexo;
    private LocalDate Datadia;
                    
            
    public Funcionario(){} 

    public Funcionario(int id_Funcionario, String Nome, int Telefone, float Salario, String Cargo, String Sexo, LocalDate Datadia)
    {
        this.id_Funcionario = id_Funcionario;
        this.Nome = Nome;
        this.Telefone = Telefone;
        this.Salario = Salario;
        this.Cargo = Cargo;
        this.Sexo = Sexo;
        this.Datadia = Datadia;
    }
    
    public int getId_Funcionario()
    {
        return id_Funcionario;
    }

    public void setId_Funcionario(int id_Funcionario)
    {
        this.id_Funcionario = id_Funcionario;
    }

    public String getNome()
    {
        return Nome;
    }

    public void setNome(String Nome)
    {
        this.Nome = Nome;
    }

    public int getTelefone()
    {
        return Telefone;
    }

    public void setTelefone(int Telefone)
    {
        this.Telefone = Telefone;
    }

    public float getSalario()
    {
        return Salario;
    }

    public void setSalario(float Salario)
    {
        this.Salario = Salario;
    }

    public String getCargo()
    {
        return Cargo;
    }

    public void setCargo(String Cargo)
    {
        this.Cargo = Cargo;
    }

    public String getSexo()
    {
        return Sexo;
    }

    public void setSexo(String Sexo)
    {
        this.Sexo = Sexo;
    }

    public LocalDate getDatadia()
    {
        return Datadia;
    }
    
    //public LocalDate getDataTable()
    {
       // return this.datadia.getDayOfMonth()+"/"+this.datadia.getMonthValue()+"/"+this.datac.getYear();
    
    }
    
    public void setData(LocalDate Datadia)
    {
        this.Datadia = Datadia;
    }

}
