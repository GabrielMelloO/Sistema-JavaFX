package javafx_aprendendo.Controls;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_RelatorioController implements Initializable
{
    
    //Labels
    @FXML private Label Txt_Descricao;
    @FXML private Label Txt_Data_Relatorio;
    
    //Buttons
    @FXML private Button BT_OK;
    @FXML private Button BT_Voltar;
    @FXML private Button BT_Limpar;
    
    //TextArea
    @FXML private TextArea TextArea_Descricao;
    
    //Datas
    @FXML private DatePicker Data_Relatorio;
 
    @FXML
    private void OK(ActionEvent event)
    {
        Stage_Relatorio.close();
    }
    
    @FXML
    private void Voltar(ActionEvent event)
    {
        Stage_Relatorio.close();
    }
    
    @FXML
    private void Limpar(ActionEvent event)
    {      
        TextArea_Descricao.setText("");
        
        Data_Relatorio.setValue(null);
    }
    
    //Cria o Stage da tela de Cadastro e da nome para ele.
    public static Stage Stage_Relatorio;
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Relatorio.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Relatório");
        stage.setScene(scene);
        stage.show();
        
        //O "Stage_Cadastro" vai receber tudo que tem na stage.
        Stage_Relatorio = stage;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
