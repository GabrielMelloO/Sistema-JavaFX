package javafx_aprendendo.Controls;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXML_HomeController implements Initializable
{   
    //Buttons
    @FXML private Button BT_Fechar;
    
    //MenusBar
    @FXML private MenuBar Menu_Home;
    
    //Menus
    @FXML private Menu Menu_Home_Cadastro;
    @FXML private Menu Menu_Home_Relatorios;
    @FXML private Menu Menu_Home_Paineis;
    
    //MenusItems
    @FXML private MenuItem Menu_Home_Cadastro_Pessoas;
    @FXML private MenuItem Menu_Home_Relatorios_Reunioes;
    @FXML private MenuItem Menu_Home_Paineis_Pesquisa;
    
    //Cria o Stage da tela Home e da nome para ele.
    public static Stage Stage_Home;
    
    @FXML
    private void Cadastrar_Pessoas(ActionEvent event)
    {
        FXML_CadastroController Abre_Tela = new FXML_CadastroController();
            try
            {
                Abre_Tela.start(new Stage());
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
    }
    
    @FXML
    private void Relatorio_Reunioes(ActionEvent event)
    {
        FXML_RelatorioController Abre_Tela = new FXML_RelatorioController();
            try
            {
                Abre_Tela.start(new Stage());
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
    }
    
    @FXML
    private void Paineis_Pesquisa(ActionEvent event)
    {
        FXML_PaineisController Abre_Tela = new FXML_PaineisController();
            try
            {
                Abre_Tela.start(new Stage());
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
    }
    
    @FXML
    private void Paineis_Grafico(ActionEvent event)
    {
        FXML_GraficosController Abre_Tela = new FXML_GraficosController();
            try
            {
                Abre_Tela.start(new Stage());
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
    }
    
    @FXML
    private void Fechar(ActionEvent event)
    {
        Platform.exit();
    }
    
    public void start(Stage stage) throws Exception
    {
        Parent root = FXMLLoader.load(getClass().getResource("FXML_Home.fxml"));
        
        Scene scene = new Scene(root);
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();
        
        //O "Stage_Home" vai receber tudo que tem na stage.
        Stage_Home = stage;
    }
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb){
        // TODO
    }    
    
}
