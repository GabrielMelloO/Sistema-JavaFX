package javafx_aprendendo.Controls;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author <Gabriel Mello de Oliveira
 */

public class FXMLDocumentController implements Initializable {
    
    //Labels
    @FXML private Label Txt_Login;
    @FXML private Label Txt_Senha;
    
    //Buttons
    @FXML private Button BT_Logar;
    @FXML private Button BT_Cancelar;
    
    //TextFields
    @FXML private TextField CT_Login; 
    
    //PasswordField
    @FXML private PasswordField CP_Senha;
    
    //ProgressBars
    @FXML private ProgressBar Carregar_Login;
    
    //Cria o Stage da tela e da nome para ele.
    @FXML public static Stage Stage;
    
    @FXML
    private void Logar(ActionEvent event) throws InterruptedException //throws InterruptedException
    {
        String Nome = CT_Login.getText();
        String Senha = CP_Senha.getText();
        
        //Carregar_Login.setVisible(true);
        
        if(Nome.equals("admin") && Senha.equals("1234"))
        {
            FXML_HomeController Abre_Tela = new FXML_HomeController();
  
            try
            {
                Alert alert = new Alert(Alert.AlertType.INFORMATION); 
            
                alert.setTitle("Sucesso!");
                alert.setHeaderText("Logado com sucesso!");
                alert.setContentText("Login realizado com sucesso!");
                alert.showAndWait();
                
                Abre_Tela.start(new Stage());
                Stage.close();
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }
        }else if(Nome.equals("") || Senha.equals(""))
        {
            Alert alert = new Alert(Alert.AlertType.WARNING); 
            
            alert.setTitle("Erro!");
            alert.setHeaderText("Campos vazios!");
            alert.setContentText("Preencha todos os campos");
            alert.showAndWait();
            
            //JOptionPane.showMessageDialog(null, "Nenhum campo pode ficar em branco, preencha todos os campos!", "Campo em Branco", JOptionPane.ERROR_MESSAGE);
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR); 
            
            alert.setTitle("Erro!");
            alert.setHeaderText("Login e/ou senha incorretos!!");
            alert.setContentText("Preencha todos os campos corretamente");
            alert.showAndWait();

            //JOptionPane.showMessageDialog(null, "Login e/ou Senha inválidos", "Erro", JOptionPane.ERROR_MESSAGE); 
        }
    }
    
    /*@FXML
    private void Cadastrar(ActionEvent event)
    {
        //O fx : id "BT_Cadastrar" vai acionar o método SetOnMouseClicked para abrir uma nova janela/tela.
        BT_Cadastrar.setOnMouseClicked((MouseEvent) -> {
            //O objeto "Abre_Tela" será responsável por abrir a Stage da tela de Cadastro.
            FXML_CadastroController Abre_Tela = new FXML_CadastroController();
            try
            {
                Abre_Tela.start(new Stage());
            }catch(Exception ex)
            {
                ex.printStackTrace();
            }  
        });
    }*/
    
    @FXML
    public void Progresso() throws InterruptedException
    {
        Double Progresso = 0.0;
               
        Progresso = Progresso + 0.05;
            
        Carregar_Login.setProgress(Progresso);

        Thread.sleep(1000);
        
        Progresso = Progresso + 0.05;
            
        Carregar_Login.setProgress(Progresso);

        Thread.sleep(1000);
        
        Progresso = Progresso + 0.05;
            
        Carregar_Login.setProgress(Progresso);

        Thread.sleep(1000);
        
        Progresso = Progresso + 0.05;
            
        Carregar_Login.setProgress(Progresso);

        Thread.sleep(1000);
    }
    
    @FXML
    private void Cancelar(ActionEvent event)
    {
        //Stage.close();
        Platform.exit();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb)
    {
        CT_Login.requestFocus();
    }    
    
}
